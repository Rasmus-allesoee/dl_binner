This is the Human Microbiome Project dataset described in CAMISIM (https://doi.org/10.1186/s40168-019-0633-6).
The data set was simulated in two blocks, the first block includes the airways, skin and urogenital samples.
The second block includes the samples from the gastrointestinal tract and the oral cavity.  
In the folder `per_bodysite`, these samples have manually been separated and gold standards per bodysite are available.  
In the main simulation folders, the separation of bodysites is as follows:  
Airways samples: 4,7,8,9,10,11,12,23,26,27  
Skin samples: 1,13,14,15,16,17,18,19,20,28  
Urogenital samples: 0,2,3,5,6,21,22,24,25  
  
Gastrointestinal samples: 0,1,2,3,4,5,9,10,11,12  
Oral samples: 6,7,8,13,14,15,16,17,18,19
